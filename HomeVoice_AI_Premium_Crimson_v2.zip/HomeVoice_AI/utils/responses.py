from pathlib import Path
import tempfile

def speak_response(text):
    """Create a spoken response file with pyttsx3, if supported on this computer."""
    try:
        import pyttsx3
        output = Path(tempfile.gettempdir()) / "homevoice_response.wav"
        engine = pyttsx3.init()
        engine.save_to_file(str(text), str(output))
        engine.runAndWait()
        if output.exists() and output.stat().st_size > 100:
            return str(output), "Voice response generated."
        return None, "Your computer's text-to-speech engine did not create an audio file."
    except Exception as e:
        return None, f"Voice response is unavailable on this computer: {e}"
