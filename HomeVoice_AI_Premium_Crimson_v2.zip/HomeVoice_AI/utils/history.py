import streamlit as st

def add_history(item):
    if "command_history" not in st.session_state:
        st.session_state.command_history = []
    st.session_state.command_history.append(item)

def load_history():
    return st.session_state.get("command_history", [])

def clear_history():
    st.session_state.command_history = []
