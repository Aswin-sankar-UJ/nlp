# HomeVoice AI — Premium Crimson Edition

A Python + Streamlit voice-controlled **virtual smart-home simulator**. This project does not connect to or control physical appliances.

## What's included

- Premium black and crimson Streamlit interface
- Overview dashboard with live virtual device states and estimated power load
- Browser microphone recording and text command input
- Speech-to-text through Google's online recognition service
- Optional audio cleanup with a safe fallback to the original recording
- NLP tokenization and TF-IDF + Logistic Regression intent classification
- Rule-based command and room/device extraction with ambiguity handling
- Virtual lights, fans, AC, TV, and appliance plug
- Synchronized brightness and fan-speed controls
- Command history, CSV export, and Plotly analytics
- NLP Lab to inspect the processing pipeline

## Requirements

- Windows 10/11, macOS, or Linux
- Python 3.10–3.12 recommended
- Internet connection for package installation and Google online speech recognition
- Microphone access for voice input (text input works without a microphone)

## Run on Windows (VS Code)

Open the extracted `HomeVoice_AI` folder in VS Code, open a terminal, and run:

```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

If PowerShell blocks activation, use Command Prompt:

```cmd
venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

Then open the local address printed by Streamlit (normally http://localhost:8501).

## Example commands

- `Turn on the bedroom light`
- `Turn off the kitchen light`
- `Increase the living room fan speed`
- `Set bedroom light brightness to 40 percent`
- `Set bedroom fan speed to 3`
- `Turn on all appliances`
- `Turn off all devices`
- `What is the status of my home?`

If more than one appliance matches a command, HomeVoice asks for the room instead of silently choosing the first device.

## Project structure

```text
HomeVoice_AI/
├── app.py
├── requirements.txt
├── README.md
├── dashboard/analytics.py
├── data/commands.csv
├── iot/
│   ├── device_catalog.py
│   └── virtual_devices.py
├── nlp/
│   ├── preprocessing.py
│   ├── intent_detection.py
│   └── command_matching.py
├── speech/
│   ├── speech_recognition.py
│   └── audio_processing.py
├── tests/test_command_matching.py
└── utils/
    ├── history.py
    └── responses.py
```

## How the processing pipeline works

1. User supplies a spoken or typed command.
2. Speech recognition converts recorded audio to text (voice input only).
3. Preprocessing tokenizes the sentence.
4. TF-IDF converts the sentence into numerical features.
5. Logistic Regression predicts an intent category.
6. Rule-based command matching extracts the action, appliance type, and room. If the target is ambiguous, the app asks the user to clarify.
7. The virtual IoT module updates the simulated device state.
8. The dashboard updates its status, history, and analytics.

The classifier predicts an intent; it does not directly operate an appliance. Device actions are executed by the command-matching and virtual-device modules.

## Important limitations

- All appliance states are simulated in the Streamlit session. No physical IoT hardware is connected.
- Estimated device loads are illustrative power values in kW, not meter readings or energy totals in kWh.
- Speech-to-text uses Google's online recognition endpoint and requires internet access.
- The intent model is a small educational TF-IDF + Logistic Regression classifier, not a large language model.
- Command history and device states are session-based and reset when the session is restarted.
- Audio noise reduction is optional; if the audio libraries cannot process a recording, the original audio is passed to speech recognition.

## Troubleshooting

- **`streamlit` not found:** activate the virtual environment and run `pip install -r requirements.txt` again.
- **Microphone unavailable:** grant microphone permission in the browser, or use the text command input.
- **Speech recognition request error:** check internet connectivity; text commands remain available.
- **Port already in use:** run `streamlit run app.py --server.port 8502`.
