import io

def clean_audio(audio_bytes):
    """
    Optional audio cleanup.
    If librosa and noisereduce are installed and the uploaded clip can be decoded,
    apply light noise reduction. Otherwise pass the original recording through.
    """
    try:
        import librosa
        import noisereduce as nr
        import soundfile as sf
        import numpy as np

        audio, sample_rate = librosa.load(io.BytesIO(audio_bytes), sr=None, mono=True)
        if len(audio) < sample_rate // 2:
            return audio_bytes
        cleaned = nr.reduce_noise(y=audio, sr=sample_rate, stationary=False)
        output = io.BytesIO()
        sf.write(output, cleaned, sample_rate, format="WAV")
        return output.getvalue()
    except Exception:
        # Keeping the original audio is safer than blocking the voice command.
        return audio_bytes
