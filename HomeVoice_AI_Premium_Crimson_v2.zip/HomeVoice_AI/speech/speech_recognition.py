import io
import speech_recognition as sr

def transcribe_audio(audio_bytes):
    """Convert a recorded WAV audio clip into text using Google's web recognizer."""
    try:
        recognizer = sr.Recognizer()
        with sr.AudioFile(io.BytesIO(audio_bytes)) as source:
            audio = recognizer.record(source)
        text = recognizer.recognize_google(audio)
        return text, None
    except sr.UnknownValueError:
        return None, "I couldn't understand the recording. Please speak clearly and try again."
    except sr.RequestError as e:
        return None, f"Speech recognition service is unavailable. Check your internet connection. Details: {e}"
    except Exception as e:
        return None, f"Audio could not be processed: {e}"
