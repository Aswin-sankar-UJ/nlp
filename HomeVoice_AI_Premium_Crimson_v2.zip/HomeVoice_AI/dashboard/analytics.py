import pandas as pd
import plotly.express as px
import streamlit as st

BG = "#17171D"
LAYOUT = dict(paper_bgcolor=BG, plot_bgcolor=BG, font_color="#E8E8ED",
              margin=dict(l=12, r=12, t=48, b=12), title_font_size=16)


def show_analytics(history, devices):
    st.markdown("### Activity insights")
    if history:
        df = pd.DataFrame(history)
        total = len(df)
        success = int((df["status"] == "Success").sum()) if "status" in df else 0
        rate = success / total * 100 if total else 0
        a, b, c = st.columns(3)
        a.metric("Commands", total)
        b.metric("Successful", success)
        c.metric("Success rate", f"{rate:.0f}%")
        left, right = st.columns(2)
        with left:
            counts = df["intent"].fillna("unknown").value_counts().rename_axis("Intent").reset_index(name="Commands")
            fig = px.bar(counts, x="Intent", y="Commands", color_discrete_sequence=["#E31B36"], title="Command frequency")
            fig.update_layout(**LAYOUT, showlegend=False)
            st.plotly_chart(fig, use_container_width=True)
        with right:
            result = df["status"].value_counts().rename_axis("Result").reset_index(name="Count")
            fig = px.pie(result, names="Result", values="Count", hole=.62,
                         color="Result", color_discrete_map={"Success":"#E31B36", "Not understood":"#777780", "Failed":"#F59E0B"}, title="Execution results")
            fig.update_layout(**LAYOUT)
            st.plotly_chart(fig, use_container_width=True)
        device_counts = df[df["device"].notna() & (df["device"] != "—")]["device"].value_counts().rename_axis("Device").reset_index(name="Commands")
        if not device_counts.empty:
            fig = px.bar(device_counts, x="Device", y="Commands", color_discrete_sequence=["#FF4057"], title="Most controlled devices")
            fig.update_layout(**LAYOUT, showlegend=False)
            st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No command activity yet. Try a few voice or text commands to populate analytics.")

    st.markdown("### Current simulated load")
    usage = pd.DataFrame([{"Device": d["name"], "Room": d["room"], "State": "ON" if d["is_on"] else "OFF",
                           "Estimated load (kW)": d["energy"] if d["is_on"] else 0.0}
                          for d in devices.values()])
    st.dataframe(usage, use_container_width=True, hide_index=True)
    st.caption("Loads are illustrative power estimates in kW, not measured energy consumption (kWh).")
