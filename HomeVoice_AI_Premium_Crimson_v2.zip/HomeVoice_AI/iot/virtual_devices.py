"""Session-backed virtual appliance state. No physical hardware is controlled."""
import streamlit as st

from iot.device_catalog import DEFAULT_DEVICES


def initialize_devices():
    if "devices" not in st.session_state:
        reset_devices()


def reset_devices():
    st.session_state.devices = {key: value.copy() for key, value in DEFAULT_DEVICES.items()}


def get_home_status():
    devices = st.session_state.devices
    on_names = [d["name"] for d in devices.values() if d["is_on"]]
    off_count = len(devices) - len(on_names)
    if not on_names:
        return f"Your home is in standby. All {len(devices)} devices are off."
    return f"{len(on_names)} devices are on and {off_count} are off: {', '.join(on_names)}."


def apply_device_action(device_key, action, value=None):
    devices = st.session_state.devices
    if action in ("all_on", "all_off"):
        turn_on = action == "all_on"
        for device in devices.values():
            device["is_on"] = turn_on
            if device["device_type"] == "fan":
                device["speed"] = max(1, device["speed"]) if turn_on else 0
        return True, "All virtual appliances have been turned " + ("on." if turn_on else "off.")

    if not device_key or device_key not in devices:
        return False, "I couldn't identify a unique device. Please specify its room and device type."

    device = devices[device_key]
    kind = device["device_type"]
    if action == "turn_on":
        device["is_on"] = True
        if kind == "fan" and device["speed"] == 0:
            device["speed"] = 1
        if kind == "light" and device["brightness"] == 0:
            device["brightness"] = 50
        return True, f"{device['name']} is now ON."
    if action == "turn_off":
        device["is_on"] = False
        if kind == "fan":
            device["speed"] = 0
        return True, f"{device['name']} is now OFF."
    if action in ("increase", "decrease"):
        delta = 1 if action == "increase" else -1
        if kind == "fan":
            device["speed"] = max(0, min(5, device["speed"] + delta))
            device["is_on"] = device["speed"] > 0
            return True, f"{device['name']} speed is {device['speed']} out of 5."
        if kind == "light":
            device["brightness"] = max(0, min(100, device["brightness"] + delta * 10))
            device["is_on"] = device["brightness"] > 0
            return True, f"{device['name']} brightness is {device['brightness']} percent."
        return False, f"Adjustment is not supported for {device['name']}."
    if action == "set_brightness":
        if kind != "light":
            return False, "Brightness can only be changed for lights."
        device["brightness"] = max(0, min(100, int(value if value is not None else 50)))
        device["is_on"] = device["brightness"] > 0
        return True, f"{device['name']} brightness set to {device['brightness']} percent."
    if action == "set_speed":
        if kind != "fan":
            return False, "Fan speed can only be changed for fans."
        device["speed"] = max(0, min(5, int(value if value is not None else 1)))
        device["is_on"] = device["speed"] > 0
        return True, f"{device['name']} speed set to {device['speed']} out of 5."
    return False, "I couldn't perform that action."
