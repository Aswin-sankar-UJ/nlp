"""Pure-Python catalogue of the simulated appliances."""

DEFAULT_DEVICES = {
    "bedroom_light": {"name":"Bedroom Light","room":"Bedroom","icon":"💡","device_type":"light","is_on":False,"brightness":70,"speed":0,"energy":0.06,"detail":"Dimmable smart light"},
    "living_room_light": {"name":"Living Room Light","room":"Living Room","icon":"💡","device_type":"light","is_on":True,"brightness":85,"speed":0,"energy":0.08,"detail":"Main ceiling light"},
    "kitchen_light": {"name":"Kitchen Light","room":"Kitchen","icon":"💡","device_type":"light","is_on":False,"brightness":70,"speed":0,"energy":0.05,"detail":"Kitchen ceiling light"},
    "bedroom_fan": {"name":"Bedroom Fan","room":"Bedroom","icon":"🌀","device_type":"fan","is_on":False,"brightness":0,"speed":0,"energy":0.07,"detail":"Five-speed virtual fan"},
    "living_room_fan": {"name":"Living Room Fan","room":"Living Room","icon":"🌀","device_type":"fan","is_on":True,"brightness":0,"speed":2,"energy":0.09,"detail":"Five-speed virtual fan"},
    "bedroom_ac": {"name":"Bedroom AC","room":"Bedroom","icon":"❄️","device_type":"ac","is_on":False,"brightness":0,"speed":0,"energy":1.20,"detail":"Virtual air conditioner"},
    "living_room_tv": {"name":"Living Room TV","room":"Living Room","icon":"📺","device_type":"tv","is_on":False,"brightness":0,"speed":0,"energy":0.12,"detail":"Smart television"},
    "kitchen_plug": {"name":"Kitchen Appliance Plug","room":"Kitchen","icon":"🔌","device_type":"plug","is_on":False,"brightness":0,"speed":0,"energy":0.30,"detail":"Virtual appliance socket"}
}
