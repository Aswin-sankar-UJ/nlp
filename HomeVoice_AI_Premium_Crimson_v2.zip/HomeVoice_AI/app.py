"""HomeVoice AI — voice-first virtual smart-home dashboard."""
from datetime import datetime
from pathlib import Path

import pandas as pd
import streamlit as st

from dashboard.analytics import show_analytics
from iot.virtual_devices import (
    DEFAULT_DEVICES, initialize_devices, reset_devices,
    apply_device_action, get_home_status,
)
from nlp.command_matching import parse_command
from nlp.intent_detection import predict_intent
from nlp.preprocessing import preprocess_text
from speech.audio_processing import clean_audio
from speech.speech_recognition import transcribe_audio
from utils.history import add_history, load_history, clear_history
from utils.responses import speak_response

BASE_DIR = Path(__file__).resolve().parent

st.set_page_config(page_title="HomeVoice AI", page_icon="🏠", layout="wide", initial_sidebar_state="expanded")

# ------------------------------ Premium Crimson design ------------------------------
st.markdown(r"""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap');
:root { --bg:#090909; --panel:#141418; --panel2:#1B1B21; --line:#2B2B33; --red:#E31B36; --red2:#FF4057; --muted:#A1A1AA; }
html, body, [class*="css"] { font-family:'DM Sans',sans-serif; }
.stApp { background:radial-gradient(ellipse at 75% 0%,rgba(227,27,54,.10),transparent 34%),var(--bg); color:#F4F4F5; }
[data-testid="stHeader"] { background:rgba(9,9,9,.88); }
[data-testid="stSidebar"] { background:#101014; border-right:1px solid #292930; }
[data-testid="stSidebar"] > div:first-child { padding-top:1.2rem; }
h1,h2,h3,h4 { font-family:'Space Grotesk',sans-serif !important; color:#FAFAFA !important; letter-spacing:-.35px; }
p, label, .stCaption { color:#C4C4CC; }
.hv-brand { font-family:'Space Grotesk'; font-size:23px; font-weight:700; letter-spacing:-.8px; color:#fff; }
.hv-brand span { color:var(--red2); }
.hv-tag { color:#85858F; font-size:10px; letter-spacing:2px; font-weight:700; margin-top:2px; }
.hv-hero { position:relative; overflow:hidden; background:linear-gradient(112deg,#1B1115 0%,#171317 52%,#211016 100%); border:1px solid #48212A; padding:28px 30px; border-radius:20px; margin:4px 0 22px; box-shadow:0 14px 50px rgba(0,0,0,.20); }
.hv-hero:after { content:''; position:absolute; width:220px;height:220px;right:-55px;top:-105px;border-radius:50%;border:1px solid rgba(255,64,87,.20);box-shadow:0 0 0 22px rgba(227,27,54,.035),0 0 0 48px rgba(227,27,54,.025); }
.hv-kicker { color:#FF687A; font-size:10px; font-weight:700; letter-spacing:2.2px; text-transform:uppercase; }
.hv-title { font-family:'Space Grotesk';font-size:clamp(25px,3.2vw,36px);font-weight:700;color:#fff;margin:7px 0 5px;letter-spacing:-1px; }
.hv-sub { color:#B8AEB2;font-size:13px;max-width:760px; }
.metric-card,.device-card { background:linear-gradient(145deg,#19191F,#121216); border:1px solid #2B2B33; border-radius:16px; padding:17px 18px; min-height:108px; }
.metric-card { box-shadow:0 8px 25px rgba(0,0,0,.12); }
.metric-label { color:#92929D;font-size:10px;text-transform:uppercase;letter-spacing:1.35px;font-weight:700; }
.metric-value { color:#FAFAFA;font-family:'Space Grotesk';font-size:27px;font-weight:700;margin-top:6px; }
.metric-note,.small-muted { color:#85858F;font-size:11px;margin-top:3px; }
.device-card { min-height:145px; margin-bottom:9px; transition:all .18s ease; }
.device-card:hover { border-color:#85303D; transform:translateY(-2px); }
.device-name { color:#F5F5F6;font-weight:700;font-size:15px;margin-top:5px; }
.device-room { color:#90909A;font-size:11px; }
.status-on { color:#FF6578;font-weight:700;font-size:11px;letter-spacing:.5px; }
.status-off { color:#888891;font-weight:700;font-size:11px;letter-spacing:.5px; }
.command-box { background:#171216;border:1px solid #54232D;border-radius:14px;padding:16px; }
div.stButton > button, div.stDownloadButton > button { border-radius:10px;border:1px solid #383840;background:#1B1B21;color:#F4F4F5;font-weight:600;transition:all .16s ease; }
div.stButton > button:hover, div.stDownloadButton > button:hover { border-color:#E31B36;color:#fff;background:#28151A; }
button[kind="primary"],div.stButton > button[kind="primary"],div.stFormSubmitButton > button[kind="primary"] { background:linear-gradient(100deg,#C9152E,#E8324B) !important;border:1px solid #F04A60 !important;color:white !important; }
[data-testid="stAudioInput"] { background:#17171D;border:1px solid #34343D;border-radius:14px;padding:12px; }
[data-testid="stMetric"] { background:#17171D;border:1px solid #2D2D35;padding:12px 14px;border-radius:13px; }
[data-testid="stMetricValue"] { color:#fff; }
.stTextInput input,.stNumberInput input { background:#17171D;color:#fff;border:1px solid #373740;border-radius:10px; }
.stSelectbox div[data-baseweb="select"] > div { background:#17171D;border-color:#373740; }
.stSlider [data-testid="stThumbValue"] { color:#FF6578; }
hr { border-color:#292930; }
[data-testid="stDataFrame"] { border:1px solid #2D2D35;border-radius:12px;overflow:hidden; }
[data-testid="stAlert"] { border-radius:12px; }
footer {visibility:hidden;}
</style>
""", unsafe_allow_html=True)

initialize_devices()
if "device_control_version" not in st.session_state:
    st.session_state["device_control_version"] = 0


def metric(label, value, note=""):
    st.markdown(
        f'<div class="metric-card"><div class="metric-label">{label}</div>'
        f'<div class="metric-value">{value}</div><div class="metric-note">{note}</div></div>',
        unsafe_allow_html=True,
    )


def hero(kicker, title, subtitle):
    st.markdown(
        f'<div class="hv-hero"><div class="hv-kicker">{kicker}</div>'
        f'<div class="hv-title">{title}</div><div class="hv-sub">{subtitle}</div></div>',
        unsafe_allow_html=True,
    )


def bump_device_controls():
    st.session_state["device_control_version"] += 1


def record_manual_action(command, device_name, action, success, response):
    add_history({
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "command": command,
        "source": "Manual", "intent": action, "device": device_name,
        "action": action, "status": "Success" if success else "Failed", "response": response,
    })


def execute_command(command, source="Text"):
    command = (command or "").strip()
    if not command:
        st.warning("Please enter or record a command first.")
        return

    parsed = parse_command(command)
    intent_result = predict_intent(command)
    action = parsed["action"]
    device_key = parsed.get("device_key")
    response = parsed.get("response", "")

    if action == "status":
        response, success = get_home_status(), True
    elif action in ("turn_on", "turn_off", "increase", "decrease", "set_brightness", "set_speed", "all_on", "all_off"):
        success, response = apply_device_action(device_key, action, parsed.get("value"))
    else:
        success = False

    add_history({
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "command": command,
        "source": source, "intent": intent_result["intent"],
        "device": parsed.get("device_name") or ("All devices" if action in ("all_on", "all_off") else "—"),
        "action": action, "status": "Success" if success else "Not understood", "response": response,
    })
    st.session_state["last_result"] = {
        "command": command, "tokens": preprocess_text(command), "intent": intent_result,
        "parsed": parsed, "success": success, "response": response,
    }
    st.session_state["last_response"] = response
    if success and action != "status":
        bump_device_controls()


def show_device_card(key, device):
    status_class = "status-on" if device["is_on"] else "status-off"
    status_label = "● ONLINE" if device["is_on"] else "○ OFFLINE"
    st.markdown(
        f'<div class="device-card"><div style="font-size:25px">{device["icon"]}</div>'
        f'<div class="device-name">{device["name"]}</div><div class="device-room">{device["room"]} · {device["detail"]}</div>'
        f'<div class="{status_class}" style="margin-top:13px">{status_label}</div></div>',
        unsafe_allow_html=True,
    )


# ------------------------------ Sidebar ------------------------------
with st.sidebar:
    st.markdown('<div class="hv-brand">HOMEVOICE <span>AI</span></div><div class="hv-tag">SMART HOME CONTROL SYSTEM</div>', unsafe_allow_html=True)
    st.markdown("---")
    pages = ["Overview", "Voice Control", "Devices", "NLP Lab", "Analytics", "Command History", "Dataset"]
    page = st.radio("WORKSPACE", pages, label_visibility="visible")
    st.markdown("---")
    active_count = sum(1 for device in st.session_state.devices.values() if device["is_on"])
    st.markdown(f"**HOME STATUS** · {'🟥 ACTIVE' if active_count else '◯ STANDBY'}")
    st.caption(f"{active_count} of {len(st.session_state.devices)} virtual devices online")
    if st.button("↻  Reset all devices", use_container_width=True):
        reset_devices()
        bump_device_controls()
        st.success("Virtual devices reset to their default state.")
        st.rerun()
    st.markdown("---")
    st.caption("DIGITAL SIMULATION · NO PHYSICAL IOT HARDWARE")

# ------------------------------ Overview ------------------------------
if page == "Overview":
    hero("YOUR DIGITAL HOME", "A smarter home starts with a command.", "Control and monitor your virtual appliances through voice, natural language, or manual controls.")
    devices = st.session_state.devices
    active = sum(1 for device in devices.values() if device["is_on"])
    history = load_history()
    estimated_load_kw = sum(device["energy"] for device in devices.values() if device["is_on"])
    c1, c2, c3, c4 = st.columns(4)
    with c1: metric("Total devices", len(devices), "Virtual appliances")
    with c2: metric("Currently online", active, "Live simulated state")
    with c3: metric("Commands processed", len(history), "Current session")
    with c4: metric("Estimated load", f"{estimated_load_kw:.2f} kW", "Illustrative power estimate")

    st.markdown("### Device overview")
    cols = st.columns(4)
    for index, (key, device) in enumerate(devices.items()):
        with cols[index % 4]:
            show_device_card(key, device)
            if st.button("Turn OFF" if device["is_on"] else "Turn ON", key=f"overview_toggle_{key}", use_container_width=True):
                action = "turn_off" if device["is_on"] else "turn_on"
                ok, message = apply_device_action(key, action)
                record_manual_action(f"Manual {action.replace('_', ' ')} {device['name']}", device["name"], action, ok, message)
                bump_device_controls()
                st.rerun()

    st.markdown("### Quick command")
    with st.form("overview_quick_command", clear_on_submit=True):
        quick_command = st.text_input("Try HomeVoice", placeholder="e.g. Turn on the bedroom light")
        quick_submit = st.form_submit_button("Run command", type="primary")
    if quick_submit:
        execute_command(quick_command)
        st.rerun()
    st.caption('Examples: “Turn on the bedroom light” · “Increase the living room fan speed” · “Turn off all devices”')

# ------------------------------ Voice Control ------------------------------
elif page == "Voice Control":
    hero("VOICE COMMAND CENTER", "Speak. Understand. Automate.", "Use your microphone or type a command. HomeVoice processes the request and updates the virtual home.")
    st.markdown("### 🎙️ Voice input")
    st.caption("Allow microphone access in your browser. Online speech transcription uses Google's recognition service and requires internet access.")
    audio_value = st.audio_input("Record a short smart-home command")
    if audio_value is not None:
        st.audio(audio_value)
        if st.button("Recognize and execute", type="primary"):
            with st.spinner("Cleaning audio and recognizing speech..."):
                audio_bytes = clean_audio(audio_value.getvalue())
                transcript, error = transcribe_audio(audio_bytes)
            if error:
                st.error(error)
            else:
                st.success(f'Recognized: “{transcript}”')
                execute_command(transcript, "Microphone")
                st.rerun()

    st.markdown("---")
    st.markdown("### Text command")
    with st.form("text_command_form", clear_on_submit=True):
        typed = st.text_input("Enter a command", placeholder="e.g. Set bedroom light brightness to 40 percent")
        submitted = st.form_submit_button("Execute command", type="primary")
    if submitted:
        execute_command(typed, "Text")
        st.rerun()

    result = st.session_state.get("last_result")
    if result:
        st.markdown("---")
        st.markdown("### Latest command result")
        st.markdown(f'<div class="command-box"><span class="small-muted">YOU SAID</span><br><b>{result["command"]}</b></div>', unsafe_allow_html=True)
        a, b, c = st.columns(3)
        with a: metric("Predicted intent", result["intent"]["intent"].replace("_", " ").upper(), f'Classifier confidence: {result["intent"]["confidence"]:.0%}')
        with b: metric("Extracted action", result["parsed"]["action"].replace("_", " ").upper(), "Rule-based command matching")
        with c: metric("Target", result["parsed"].get("device_name") or "Home / unspecified", "Device entity")
        if result["success"]:
            st.success(result["response"])
        else:
            st.warning(result["response"])
        with st.expander("Inspect NLP processing"):
            st.write("**Tokens:**", result["tokens"])
            st.write("**Intent classifier:**", result["intent"])
            st.json(result["parsed"])
        if st.button("🔊 Read response aloud"):
            audio_path, message = speak_response(result["response"])
            if audio_path:
                st.audio(audio_path)
            else:
                st.info(message)

    with st.expander("Command examples"):
        st.markdown("""
        - Turn on the bedroom light
        - Switch off the kitchen light
        - Turn on all appliances
        - Turn off all devices
        - Increase the living room fan speed
        - Set bedroom light brightness to 40 percent
        - Set bedroom fan speed to 3
        - What is the status of my home?
        """)

# ------------------------------ Devices ------------------------------
elif page == "Devices":
    hero("DEVICE CONTROL", "Every appliance, one place.", "Manually adjust the state, brightness, and fan speed of your virtual appliances.")
    for key, device in st.session_state.devices.items():
        with st.container(border=True):
            left, middle, right = st.columns([1, 3, 1.2])
            with left:
                st.markdown(f"<div style='font-size:36px;padding-top:8px'>{device['icon']}</div>", unsafe_allow_html=True)
            with middle:
                st.markdown(f"**{device['name']}**")
                st.caption(f"{device['room']} · {device['detail']}")
                st.markdown("🟥 **ON**" if device["is_on"] else "⚪ **OFF**")
                if device["device_type"] == "light":
                    control_version = st.session_state["device_control_version"]
                    brightness = st.slider("Brightness", 0, 100, int(device["brightness"]), key=f"brightness_{key}_{control_version}")
                    if brightness != device["brightness"]:
                        ok, message = apply_device_action(key, "set_brightness", brightness)
                        record_manual_action(f"Set {device['name']} brightness to {brightness}%", device["name"], "set_brightness", ok, message)
                    st.caption("0% switches the light off; any value above 0% switches it on.")
                elif device["device_type"] == "fan":
                    control_version = st.session_state["device_control_version"]
                    speed = st.slider("Fan speed", 0, 5, int(device["speed"]), key=f"speed_{key}_{control_version}")
                    if speed != device["speed"]:
                        ok, message = apply_device_action(key, "set_speed", speed)
                        record_manual_action(f"Set {device['name']} speed to {speed}", device["name"], "set_speed", ok, message)
                    st.caption("0 stops the fan; 1–5 sets the fan speed.")
            with right:
                st.write("")
                if st.button("Turn OFF" if device["is_on"] else "Turn ON", key=f"device_toggle_{key}", use_container_width=True):
                    action = "turn_off" if device["is_on"] else "turn_on"
                    ok, message = apply_device_action(key, action)
                    record_manual_action(f"Manual {action.replace('_', ' ')} {device['name']}", device["name"], action, ok, message)
                    bump_device_controls()
                    st.rerun()

# ------------------------------ NLP Lab ------------------------------
elif page == "NLP Lab":
    hero("NLP WORKSPACE", "Inside the command engine.", "Explore how HomeVoice tokenizes a sentence, predicts intent, and extracts the requested appliance.")
    with st.form("nlp_form"):
        sample = st.text_input("Enter a sentence to analyze", "Please turn on the bedroom light")
        analyze = st.form_submit_button("Analyze command", type="primary")
    if analyze:
        tokens = preprocess_text(sample)
        intent = predict_intent(sample)
        parsed = parse_command(sample)
        x1, x2, x3 = st.columns(3)
        with x1: metric("Token count", len(tokens), "Text preprocessing")
        with x2: metric("Predicted intent", intent["intent"].replace("_", " ").upper(), f'Confidence: {intent["confidence"]:.0%}')
        with x3: metric("Matched device", parsed.get("device_name") or "Not uniquely identified", "Rule-based entity matching")
        st.markdown("#### 1 · Tokenization")
        st.code("  |  ".join(tokens) if tokens else "No tokens found")
        st.markdown("#### 2 · Intent classification")
        st.json(intent)
        st.markdown("#### 3 · Action and entity extraction")
        st.json(parsed)
        st.info("The TF-IDF + Logistic Regression model predicts the intent category. Separate rule-based matching extracts the action, room, and device. The virtual IoT module then changes the simulated device state.")

# ------------------------------ Analytics ------------------------------
elif page == "Analytics":
    hero("HOME INSIGHTS", "Your activity, visualized.", "Review command outcomes, frequently controlled devices, and illustrative virtual appliance loads.")
    show_analytics(load_history(), st.session_state.devices)

# ------------------------------ Command History ------------------------------
elif page == "Command History":
    hero("ACTIVITY LOG", "A record of every interaction.", "Review commands issued through microphone, text, and manual controls.")
    history = load_history()
    if history:
        df = pd.DataFrame(history)
        st.dataframe(df.iloc[::-1], use_container_width=True, hide_index=True)
        st.download_button("Download command history CSV", df.to_csv(index=False).encode("utf-8"), "homevoice_command_history.csv", "text/csv")
        if st.button("Clear command history"):
            clear_history()
            st.rerun()
    else:
        st.info("No commands have been recorded yet. Try the Voice Control page or adjust a device manually.")

# ------------------------------ Dataset ------------------------------
elif page == "Dataset":
    hero("COMMAND DATASET", "The examples behind the model.", "Explore the sample utterances used to train the TF-IDF and Logistic Regression intent classifier.")
    dataset_path = BASE_DIR / "data" / "commands.csv"
    try:
        df = pd.read_csv(dataset_path)
        st.dataframe(df, use_container_width=True, hide_index=True)
        st.caption(f"{len(df)} sample utterances · Dataset stored locally in data/commands.csv")
        st.download_button("Download training dataset", df.to_csv(index=False).encode("utf-8"), "homevoice_commands.csv", "text/csv")
    except Exception as exc:
        st.error(f"Could not load dataset: {exc}")

st.markdown("---")
st.caption("HOMEVOICE AI · PREMIUM CRIMSON EDITION · DIGITAL SIMULATION ONLY · NO PHYSICAL IOT DEVICES ARE CONNECTED")
