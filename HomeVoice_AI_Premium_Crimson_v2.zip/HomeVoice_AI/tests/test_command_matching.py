import unittest
from nlp.command_matching import parse_command


class CommandMatchingTests(unittest.TestCase):
    def test_room_and_device_match(self):
        result = parse_command("Turn on the bedroom light")
        self.assertEqual(result["action"], "turn_on")
        self.assertEqual(result["device_key"], "bedroom_light")

    def test_ambiguous_device_requests_clarification(self):
        result = parse_command("Turn on the light")
        self.assertEqual(result["action"], "ambiguous")
        self.assertEqual(len(result["candidates"]), 3)

    def test_set_brightness(self):
        result = parse_command("Set bedroom light brightness to 40 percent")
        self.assertEqual(result["action"], "set_brightness")
        self.assertEqual(result["value"], 40)

    def test_set_fan_speed(self):
        result = parse_command("Set bedroom fan speed to 3")
        self.assertEqual(result["action"], "set_speed")
        self.assertEqual(result["value"], 3)

    def test_all_devices_off(self):
        result = parse_command("Turn off all devices")
        self.assertEqual(result["action"], "all_off")

    def test_home_status(self):
        result = parse_command("What is the status of my home?")
        self.assertEqual(result["action"], "status")

    def test_switch_word_order(self):
        result = parse_command("Switch the bedroom fan off")
        self.assertEqual(result["action"], "turn_off")
        self.assertEqual(result["device_key"], "bedroom_fan")


if __name__ == "__main__":
    unittest.main()
