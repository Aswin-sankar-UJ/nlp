# Changelog

## HomeVoice AI 2.0 — Premium Crimson Edition

- Replaced the original blue/navy styling with a black, charcoal, and crimson interface.
- Refined the dashboard layout and device cards.
- Added explicit device-room ambiguity handling so a generic request such as "turn on the light" asks which room instead of selecting an arbitrary light.
- Added direct fan-speed setting commands (for example, "set bedroom fan speed to 3").
- Kept brightness and fan speed synchronized with simulated ON/OFF state.
- Added versioned widget keys so voice commands and reset actions refresh the manual control sliders consistently.
- Corrected the overview load label to kW and clarified that values are illustrative power estimates, not kWh measurements.
- Updated analytics to use the crimson theme and show command success metrics.
- Added seven automated tests for command parsing and ambiguity handling.
- Kept the existing modular Python/Streamlit architecture and virtual-only IoT approach.
