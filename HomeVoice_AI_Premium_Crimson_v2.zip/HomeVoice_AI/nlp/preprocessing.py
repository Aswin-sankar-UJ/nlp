import re

def preprocess_text(text):
    """Lowercase a sentence and split it into simple word tokens."""
    text = (text or "").lower()
    return re.findall(r"[a-z0-9]+", text)
