from pathlib import Path
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

MODEL = None
VECTORIZER = None
FALLBACK_EXAMPLES = {
    "turn_on": ["turn on the bedroom light", "switch on the fan", "activate the tv", "start the air conditioner", "lights on", "power up the kitchen appliance", "please enable the living room light", "i want the bedroom fan on"],
    "turn_off": ["turn off the bedroom light", "switch off the fan", "deactivate the tv", "stop the air conditioner", "lights off", "shut down the appliance", "please disable the kitchen light", "switch the bedroom fan off"],
    "increase": ["increase the fan speed", "make the light brighter", "turn up the fan", "increase brightness", "raise the bedroom fan speed", "make the living room light brighter"],
    "decrease": ["decrease the fan speed", "dim the light", "turn down the fan", "lower brightness", "reduce the bedroom fan speed", "make the light dimmer"],
    "status": ["what is the status of my home", "show home status", "which devices are on", "tell me the device status", "give me a home overview", "show all device states"],
}


def train_model():
    global MODEL, VECTORIZER
    examples, labels = [], []
    csv_path = Path(__file__).resolve().parents[1] / "data" / "commands.csv"
    try:
        df = pd.read_csv(csv_path)
        if {"command", "intent"}.issubset(df.columns):
            for _, row in df.dropna(subset=["command", "intent"]).iterrows():
                examples.append(str(row["command"]))
                labels.append(str(row["intent"]))
    except (OSError, ValueError, KeyError):
        pass
    for label, phrases in FALLBACK_EXAMPLES.items():
        examples.extend(phrases)
        labels.extend([label] * len(phrases))
    VECTORIZER = TfidfVectorizer(ngram_range=(1, 2), lowercase=True, sublinear_tf=True)
    matrix = VECTORIZER.fit_transform(examples)
    MODEL = LogisticRegression(max_iter=700, class_weight="balanced", random_state=42)
    MODEL.fit(matrix, labels)


def predict_intent(text):
    global MODEL, VECTORIZER
    if MODEL is None or VECTORIZER is None:
        train_model()
    vector = VECTORIZER.transform([text or ""])
    probabilities = MODEL.predict_proba(vector)[0]
    best = probabilities.argmax()
    return {"intent": MODEL.classes_[best], "confidence": float(probabilities[best])}
