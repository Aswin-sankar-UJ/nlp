"""Readable rule-based extraction of actions, devices, and rooms."""
import re
from iot.device_catalog import DEFAULT_DEVICES

ACTION_PATTERNS = {
    "turn_on": (r"\b(turn|switch|power) on\b", r"\b(turn|switch) .+ on\b", r"\b(activate|enable|start)\b", r"\blights on\b"),
    "turn_off": (r"\b(turn|switch|power) off\b", r"\b(turn|switch) .+ off\b", r"\b(deactivate|disable|stop|shut down)\b", r"\blights off\b"),
    "increase": (r"\b(increase|raise|higher|brighter|turn up)\b",),
    "decrease": (r"\b(decrease|lower|reduce|dim|turn down)\b",),
}

SYNONYMS = {
    "light": {"light", "lights", "lamp", "lamps", "bulb", "bulbs"},
    "fan": {"fan", "fans", "cooler"},
    "ac": {"ac", "air conditioner", "air conditioning", "aircon"},
    "tv": {"tv", "television"},
    "plug": {"plug", "socket", "outlet", "appliance"},
}
ROOMS = {"bedroom", "living room", "kitchen"}


def parse_command(text):
    original = (text or "").strip()
    clean = re.sub(r"[^a-z0-9% ]+", " ", original.lower())
    clean = re.sub(r"\s+", " ", clean).strip()

    if not clean:
        return _result("unknown", response="Please enter a command.")

    if any(p in clean for p in ("status", "how many devices", "which devices", "home overview", "show devices")):
        return _result("status", device_name="Home", response="Here is your home status.")

    all_target = any(p in clean for p in ("all appliances", "all devices", "everything", "whole house", "entire home"))
    action = None
    for candidate, patterns in ACTION_PATTERNS.items():
        if any(re.search(pattern, clean) for pattern in patterns):
            action = candidate
            break

    value = None
    brightness_match = re.search(r"(?:brightness\s*(?:to)?|to)\s*(\d{1,3})\s*(?:percent|%)?", clean)
    if "brightness" in clean and brightness_match:
        action = "set_brightness"
        value = max(0, min(100, int(brightness_match.group(1))))

    speed_match = re.search(r"(?:speed\s*(?:to)?|to)\s*([1-5])\b", clean)
    if "speed" in clean and speed_match:
        action = "set_speed"
        value = int(speed_match.group(1))

    if all_target and action in ("turn_on", "turn_off"):
        return _result("all_on" if action == "turn_on" else "all_off", device_name="All devices", response="Updating all virtual devices.")

    # Identify requested device category and room explicitly, rather than relying on dictionary order.
    requested_types = set()
    for device_type, terms in SYNONYMS.items():
        if any(term in clean for term in terms):
            requested_types.add(device_type)
    requested_rooms = [room for room in ROOMS if room in clean]

    candidates = [(key, device) for key, device in DEFAULT_DEVICES.items()
                  if (not requested_types or device["device_type"] in requested_types)
                  and (not requested_rooms or device["room"].lower() in requested_rooms)]

    # If no explicit device term was found, do not guess from room alone.
    if not requested_types:
        candidates = []

    if len(candidates) > 1:
        names = [device["name"] for _, device in candidates]
        return _result("ambiguous", device_name=None, candidates=[key for key, _ in candidates],
                       response="I found more than one matching device. Please specify a room: " + ", ".join(names) + ".")

    matched_key, matched_device = candidates[0] if len(candidates) == 1 else (None, None)

    if action is None:
        return _result("unknown", device_key=matched_key,
                       device_name=matched_device["name"] if matched_device else None,
                       response="I couldn't identify the requested action. Try 'turn on the bedroom light' or 'turn off all devices'.")

    if action in ("increase", "decrease", "set_brightness") and matched_device and matched_device["device_type"] not in ("light", "fan"):
        return _result("unsupported", device_key=matched_key, device_name=matched_device["name"], value=value,
                       response="Brightness and speed adjustments are supported for lights and fans only.")

    if matched_device is None and action not in ("all_on", "all_off"):
        if requested_types:
            return _result("ambiguous", response="Please specify the room for that device, for example 'turn on the bedroom light'.")
        return _result("unknown", response="Please mention a device, such as a light, fan, AC, TV, or plug.")

    return _result(action, device_key=matched_key, device_name=matched_device["name"], value=value,
                   response="Command identified.")


def _result(action, device_key=None, device_name=None, value=None, response="", **extra):
    return {"action": action, "device_key": device_key, "device_name": device_name,
            "value": value, "response": response, **extra}
